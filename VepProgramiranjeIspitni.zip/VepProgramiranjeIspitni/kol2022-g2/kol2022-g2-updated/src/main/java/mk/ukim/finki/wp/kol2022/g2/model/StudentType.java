package mk.ukim.finki.wp.kol2022.g2.model;

public enum StudentType {
    ADMIN,
    UNDERGRADUATE,
    MASTER
}
