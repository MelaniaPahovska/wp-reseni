package mk.ukim.finki.wp.june2021.model;

public enum MatchType {
    FRIENDLY,
    COMPETITIVE,
    CHARITY
}
