package mk.ukim.finki.wp.september2021.repository;

public interface NewsCategoryRepository  {
}
