package mk.ukim.finki.wp.september2021.model;

public enum NewsType {
    DRAFT,
    PUBLIC,
    PROMOTION
}
